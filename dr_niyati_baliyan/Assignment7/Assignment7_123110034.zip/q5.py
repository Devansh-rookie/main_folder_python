from tkinter import *

window = Tk()

# window.minsize(400,400)# this sets the minimum size of the window size can't be reduced from it but can be increased
# window.maxsize(400,400) # now it can't be increased
# or 
window.resizable(False, False)

window.mainloop()