from tkinter import *

window = Tk()

window.title("Question 1")
window.geometry("400x300")

window.mainloop()