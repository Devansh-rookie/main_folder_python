from tkinter import *

window = Tk()

window.geometry("400x300")
window.title("Question 2")
myLabel = Label(window,text="Label 1 for Question 2")
myLabel.grid(row=0, column=0)
window.mainloop()